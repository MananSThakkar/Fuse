package com.team8.fuse;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;
import com.google.firebase.firestore.auth.User;

import java.util.ArrayList;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

public class MainPageContainerActivity extends AppCompatActivity implements PlacesFragment.PlaceButtonClickHandler{

    FirebaseAuth mAuth;
    ActionBar mActionBar;

    private boolean mLocationPermissionGranted = false;
    private Location mLastKnownLocation;
    private FusedLocationProviderClient mFusedLocationProviderClient;
    FirebaseFirestore mFirestoreDatabase;
    FirebaseDatabase mFirebaseDatabase;
    private static final int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1;
    private static final String TAG = "MAINPAGE";
    private ArrayList<UserLocation> mUserLocations = new ArrayList<>();

    UserLocation mUserLocation;


    private Toolbar mToolbar;
    //  private Button logout;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        mAuth = FirebaseAuth.getInstance();

        mActionBar = getSupportActionBar();
        mActionBar.setTitle("Fuse");
        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        mFirestoreDatabase = FirebaseFirestore.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();

        if(!mLocationPermissionGranted){
            getLocationPermission();
        }

        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().add(R.id.view_container, new PlacesFragment()).commit();

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.action_home:
                mActionBar.setTitle("User");
                HomeFragment homeFragment = new HomeFragment();
                getSupportFragmentManager().beginTransaction().replace(R.id.view_container, homeFragment).commit();
                return true;
            case R.id.action_chats:
                mActionBar.setTitle("Home");
                ChatsFragment chatsFragment = new ChatsFragment();
                getSupportFragmentManager().beginTransaction().replace(R.id.view_container, chatsFragment).commit();
                return true;
            case R.id.action_places:
                mActionBar.setTitle("Profile");
                PlacesFragment placesFragment = new PlacesFragment();
                getSupportFragmentManager().beginTransaction().replace(R.id.view_container, placesFragment).commit();
                return true;
        }
        return false;
    });
    }

    private void saveUserLocation(){
        if(mUserLocation != null){
            DocumentReference locationRef = mFirestoreDatabase.collection(getString(R.string.collection_user_locations)).document(mAuth.getCurrentUser().getUid());
            locationRef.set(mUserLocation).addOnCompleteListener(task -> {
                if(task.isSuccessful()){
                    Log.d(TAG, "Location saved!");
                }
            });
        }
    }

    public void getUserDetails(){
        if(mUserLocation == null) {
            mUserLocation = new UserLocation();
            DocumentReference userRef = mFirestoreDatabase.collection(getString(R.string.collection_users)).document(mAuth.getCurrentUser().getUid());
            userRef.get().addOnCompleteListener(task->{
                if(task.isSuccessful()){
                    Log.d(TAG, "Got user details");
                    UserProfile user = task.getResult().toObject(UserProfile.class);
                    mUserLocation.setmUser(user);
                    getDeviceLocation();
                }
            });
        }
    }


    public void getDeviceLocation() {
        try {
            if (mLocationPermissionGranted) {
                Task<Location> locationResult = mFusedLocationProviderClient.getLastLocation();
                locationResult.addOnCompleteListener(this, task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        mLastKnownLocation = task.getResult();
                        GeoPoint geoPoint = new GeoPoint(mLastKnownLocation.getLatitude(), mLastKnownLocation.getLongitude());
                        Log.d(TAG, "GeoPoint latitude:" + geoPoint.getLatitude());
                        Log.d(TAG, "GeoPoint longitude:" + geoPoint.getLongitude());

                        mUserLocation.setmGeo_point(geoPoint);
                        mUserLocation.setmTimestamp(null);
                        saveUserLocation();
                        Location mockLocation = new Location(LocationManager.GPS_PROVIDER);
                        mockLocation.setLatitude(0);
                        mockLocation.setLongitude(0);

                        LatLngBounds mp = new LatLngBounds(new LatLng(mockLocation.getLatitude(),mockLocation.getLongitude()),new LatLng(mLastKnownLocation.getLatitude(),mLastKnownLocation.getLongitude()));
                        Location midPoint = new Location("");
                        midPoint.setLatitude(mp.getCenter().latitude);
                        midPoint.setLongitude(mp.getCenter().longitude);

                        mFusedLocationProviderClient.setMockMode(true);
                        mFusedLocationProviderClient.setMockLocation(midPoint);
                        Task<Location> midLocationResult = mFusedLocationProviderClient.getLastLocation();
                        midLocationResult.addOnCompleteListener(this, task1 -> {
                            if (task1.isSuccessful() && task1.getResult() != null) {
                                mLastKnownLocation = task1.getResult();
                            }
                        });
                    } else {
                        Log.d(TAG, "Current location is null. Using defaults.");
                        Log.e(TAG, "Exception: %s", task.getException());
                    }
                });
            }
        } catch(SecurityException e)  {
            Log.e("Exception: %s", e.getMessage());
        }
    }

    public void getLocationPermission() {
        if (ContextCompat.checkSelfPermission(this.getApplicationContext(), ACCESS_FINE_LOCATION)  == PackageManager.PERMISSION_GRANTED) {
            mLocationPermissionGranted = true;
            getUserDetails();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        mLocationPermissionGranted = false;
        switch (requestCode) {
            case PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    mLocationPermissionGranted = true;
                    getUserDetails();
                }
                else{
                    getLocationPermission();
                }
            }
        }
    }

    private void Logout(){
        mAuth.signOut();
        finish();
        startActivity(new Intent(MainPageContainerActivity.this, SignIn.class));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        if(item.getItemId() == R.id.profileMenu){
            startActivity(new Intent(MainPageContainerActivity.this, Profile.class));
        }
        if(item.getItemId() == R.id.logoutMenu){
            Logout();
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onClickMeClicked() {
    }

    private void getUsers(){
        //Whatever manan does to get the list of all the users
        //for(QueryDocumentSnapshot doc : queryDocumentSnapshots) {
            //UserProfile user = doc.toObject(UserProfile.class);
            //mUserList.add(user);
            //getUserLocation(user);
        //}
    }
    private void getUserLocation(User user){
        @SuppressLint("RestrictedApi") DocumentReference locationRef = mFirestoreDatabase.collection(getString(R.string.collection_user_locations)).document(user.getUid());
        locationRef.get().addOnCompleteListener(task -> {
            if(task.isSuccessful()){
                if (task.getResult().toObject(UserLocation.class)!=null){
                    mUserLocations.add(task.getResult().toObject(UserLocation.class));
                    PlacesFragment placesFragment = PlacesFragment.newInstance();
                    Bundle bundle = new Bundle();
                    bundle.putParcelableArrayList(getString(R.string.intent_user_locations), mUserLocations);
                }
            }
        });
    }
}
