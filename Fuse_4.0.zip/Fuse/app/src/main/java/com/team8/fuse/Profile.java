package com.team8.fuse;


import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

public class Profile extends AppCompatActivity {

    private Button updateProfile;
    private EditText userName, userStatus;
    private TextView userEmail;
    private CircleImageView userProfileImage;
    private FirebaseAuth mAuth;
    private FirebaseDatabase firebaseDatabase;
    private static int PICK_IMAGE = 123;
    Uri imagePath;
    private FirebaseStorage firebaseStorage;
    private StorageReference storageReference;
    private DatabaseReference myRef;
    private String downloadURL;
    private ProgressDialog loadingBar;
    private String currentUserId;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        InitializeFields();
        mAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        currentUserId = mAuth.getCurrentUser().getUid();
        firebaseStorage = FirebaseStorage.getInstance();
        myRef = firebaseDatabase.getReference("User");


        myRef.child(currentUserId);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    String name = snapshot.child("userName").getValue().toString();
                    String email = snapshot.child("userEmail").getValue().toString();
                    String status = snapshot.child("userStatus").getValue().toString();
                //    String profileImage = snapshot.child("image").getValue().toString();

                    userName.setText(name);
                    userStatus.setText(status);
                    userEmail.setText(email);
                 //   Picasso.get().load(profileImage).placeholder(R.drawable.profile_image).into(userProfileImage);
                }



                /*if((dataSnapshot.exists()) && (dataSnapshot.hasChild("userName"))){
                    String name = dataSnapshot.child("userName").getValue().toString();
                    String email = dataSnapshot.child("userEmail").getValue().toString();
                    String status = dataSnapshot.child("userStatus").getValue().toString();

                    userName.setText(name);
                    userStatus.setText(status);
                    userEmail.setText(email); */



            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

     storageReference = firebaseStorage.getReference();
    storageReference.child("User").child((mAuth.getUid())).child("Images/Profile Pic").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {

                Picasso.get().load(uri).into(userProfileImage);
            }
        });


        updateProfile.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                UpdateProfile();
                }
        });

        userProfileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
              //  startActivityForResult(Intent.createChooser(intent, "Select Image"), PICK_IMAGE);
                startActivityForResult(intent, PICK_IMAGE);
            }
        });


    }

    private void UpdateProfile() {
        String name = userName.getText().toString();
        String status =  userStatus.getText().toString();
        String email = userEmail.getText().toString();

        if(TextUtils.isEmpty(name)){
            Toast.makeText(Profile.this, "Please write the user name...",Toast.LENGTH_SHORT).show();
        }if(TextUtils.isEmpty(status)){
            Toast.makeText(Profile.this, "Please write your status...",Toast.LENGTH_SHORT).show();
        }else {
            HashMap<String, String> profileMap = new HashMap<>();
            profileMap.put("userName", name);
            profileMap.put("userStatus", status);
            profileMap.put("userEmail", email);

            myRef.child(currentUserId).setValue(profileMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()) {
                        Toast.makeText(Profile.this, "Profile updated", Toast.LENGTH_SHORT).show();
                    }else{
                        String Message = task.getException().toString();
                        Toast.makeText(Profile.this, "Error: " + Message, Toast.LENGTH_SHORT).show();
                    }
                }
            });

        }
    }


    @SuppressLint("WrongViewCast")
    private void InitializeFields() {
        updateProfile = (Button)findViewById(R.id.update_profile);
        userName = (EditText)findViewById(R.id.set_user_name);
        userEmail = (TextView)findViewById(R.id.set_user_email);
        userStatus = (EditText)findViewById(R.id.set_profile_status);
        userProfileImage = (CircleImageView) findViewById(R.id.set_profile_image);
        loadingBar = new ProgressDialog(this);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE && resultCode==RESULT_OK && data!=null) {
            imagePath = data.getData();

            CropImage.activity()
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .setAspectRatio(1,1)
                    .start(this);
        }
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if(resultCode==RESULT_OK){
                loadingBar.setTitle("Set Profile Image");
                loadingBar.setMessage("Uploading your profile Image...");
                loadingBar.setCanceledOnTouchOutside(false);
                loadingBar.show();
                Uri resultUri = result.getUri();

                StorageReference imageReference = storageReference.child("User").child(mAuth.getUid()).child("Images/Profile Pic");
                imageReference.putFile(resultUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(Profile.this, "Upload Successful!", Toast.LENGTH_SHORT).show();
                             downloadURL = task.getResult().getStorage().getDownloadUrl().toString();
                             myRef.child(mAuth.getUid()).child("image").setValue(downloadURL).addOnCompleteListener(new OnCompleteListener<Void>() {
                                 @Override
                                 public void onComplete(@NonNull Task<Void> task) {
                                     if (task.isSuccessful()) {
                                         Toast.makeText(Profile.this, "Upload Successful!", Toast.LENGTH_SHORT).show();
                                         loadingBar.dismiss();
                                     }else{
                                         Toast.makeText(Profile.this, "Upload Failed!", Toast.LENGTH_SHORT).show();
                                         loadingBar.dismiss();
                                     }
                                 }
                             });

                             loadingBar.dismiss();
                        }
                        else{
                            String message = task.getException().toString();
                            Toast.makeText(Profile.this, "Upload Failed!" + message, Toast.LENGTH_SHORT).show();
                            loadingBar.dismiss();
                        }
                    }
                });
            }
        }
    }
}