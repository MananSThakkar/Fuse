package com.team8.fuse;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.firebase.firestore.GeoPoint;
import com.google.firebase.firestore.ServerTimestamp;

import java.util.Date;

public class UserLocation implements Parcelable {
    GeoPoint mGeo_point;
    @ServerTimestamp Date mTimestamp;
    UserProfile mUser;

    public UserLocation(GeoPoint geo_point, Date timestamp, UserProfile user){
        mGeo_point = geo_point;
        mTimestamp = timestamp;
        mUser = user;
    }

    public UserLocation() {

    }

    protected UserLocation(Parcel in) {
        mUser = in.readParcelable(UserProfile.class.getClassLoader());
    }

    public static final Creator<UserLocation> CREATOR = new Creator<UserLocation>() {
        @Override
        public UserLocation createFromParcel(Parcel in) {
            return new UserLocation(in);
        }

        @Override
        public UserLocation[] newArray(int size) {
            return new UserLocation[size];
        }
    };

    public GeoPoint getmGeo_point() {
        return mGeo_point;
    }

    public void setmGeo_point(GeoPoint mGeo_point) {
        this.mGeo_point = mGeo_point;
    }

    public Date getmTimestamp() {
        return mTimestamp;
    }

    public void setmTimestamp(Date mTimestamp) {
        this.mTimestamp = mTimestamp;
    }

    public UserProfile getmUser() {
        return mUser;
    }

    public void setmUser(UserProfile mUser) {
        this.mUser = mUser;
    }

    @Override
    public String toString() {
        return "UserLocation{" +
                "mGeo_point=" + mGeo_point +
                ", mTimestamp='" + mTimestamp + '\'' +
                ", mUser=" + mUser +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(mUser, flags);
    }
}
