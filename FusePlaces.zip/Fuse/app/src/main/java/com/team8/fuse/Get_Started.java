package com.team8.fuse;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.auth.UserInfo;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.auth.User;

public class Get_Started extends AppCompatActivity {

    private EditText userName, userPassword, userEmail;
    private Button regButton;
    private TextView userLogin;
    private FirebaseAuth mAuth;
    private ImageView userProfilePic;
    String email, name, password, status;

    SignInButton mGoogleSignUp;
    GoogleSignInClient mGoogleSignInClient;
    private static final String TAG = "SignInActivity";
    private static final int RC_SIGN_IN = 9001;
    private FirebaseFirestore mDb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_started);
        setupUIViews();
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken(getString(R.string.default_web_client_id)).requestEmail().build();
        mGoogleSignInClient = GoogleSignIn.getClient(this,gso);
        mGoogleSignUp.setOnClickListener(v->googleSignUp());
        mAuth = FirebaseAuth.getInstance();
        mDb = FirebaseFirestore.getInstance();

        regButton.setOnClickListener(view -> {
            if(validate()){
                String user_email = userEmail.getText().toString().trim();
                String user_password = userPassword.getText().toString().trim();

                mAuth.createUserWithEmailAndPassword(user_email, user_password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if(task.isSuccessful()){
                            sendEmailVerification();
                            sendUserData();

                        }else{
                            Toast.makeText(Get_Started.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

        userLogin.setOnClickListener(view -> startActivity(new Intent(Get_Started.this, SignIn.class)));
    }

    private void googleSignUp() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                firebaseAuthWithGoogle(account);
            } catch (ApiException e) {
                Log.w(TAG, "Google sign in failed", e);
                updateUI(null);
            }
        }
    }
    private void firebaseAuthWithGoogle(GoogleSignInAccount acct) {
        Log.d(TAG, "firebaseAuthWithGoogle:" + acct.getId());
        AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        mAuth.signInWithCredential(credential).addOnCompleteListener(this, task -> {
            if (task.isSuccessful()) {
                // Sign in success, update UI with the signed-in user's information
                Log.d(TAG, "signInWithCredential:success");
                FirebaseUser user = mAuth.getCurrentUser();
                updateUI(user);
            } else {
                // If sign in fails, display a message to the user.
                Log.w(TAG, "signInWithCredential:failure", task.getException());
                Toast.makeText(this, "Firebase Auth failed", Toast.LENGTH_SHORT).show();
                updateUI(null);
            }
        });
    }


    private void updateUI(FirebaseUser user) {
        if (user != null) {
            finish();
            Intent intent = new Intent(this, MainPageContainerActivity.class);
            for (UserInfo profile : user.getProviderData()) {
                String name = profile.getDisplayName();
                String email = profile.getEmail();
                FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
                DatabaseReference myRef = firebaseDatabase.getReference().child("User").child(user.getUid());
                UserProfile userProfile = new UserProfile(name, email, status);
                myRef.setValue(userProfile);

                DocumentReference newUserRef = mDb.collection(getString(R.string.collection_users)).document(mAuth.getUid());
                newUserRef.set(userProfile);
            }
            startActivity(intent);
        }
    }

    private void setupUIViews(){
        userName = findViewById(R.id.etUserName);
        userPassword = findViewById(R.id.etPassword);
        userEmail = findViewById(R.id.etEmail);
        regButton = findViewById(R.id.btnSignUp);
        userLogin = findViewById(R.id.logedin);
        userProfilePic = findViewById(R.id.ivProfile);
        mGoogleSignUp = findViewById(R.id.googleSignUp);
    }

    private Boolean validate(){
        Boolean result = false;
        name = userName.getText().toString();
        password = userPassword.getText().toString();
        email = userEmail.getText().toString();
        if(name.isEmpty() || password.isEmpty() || email.isEmpty()){
            Toast.makeText(this, "Please enter all the details", Toast.LENGTH_SHORT).show();
        }else{
            result = true;
        }
        return result;
    }

    private void sendEmailVerification(){
        FirebaseUser firebaseUser = mAuth.getCurrentUser();
        if(firebaseUser!=null){
            firebaseUser.sendEmailVerification().addOnCompleteListener(task -> {
                if(task.isSuccessful()){
                    sendUserData();
                    Toast.makeText(Get_Started.this, "Successfully Registered, Verification email sent!", Toast.LENGTH_SHORT).show();
                    mAuth.signOut();
                    finish();
                    startActivity(new Intent(Get_Started.this, SignIn.class));
                }else{
                    Toast.makeText(Get_Started.this, "Please recheck the email entered!", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void sendUserData(){
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference myRef = firebaseDatabase.getReference().child("User").child(mAuth.getUid());
        UserProfile userProfile = new UserProfile(name, email, status);
        myRef.setValue(userProfile);

        DocumentReference newUserRef = mDb.collection(getString(R.string.collection_users)).document(mAuth.getUid());
        newUserRef.set(userProfile);
    }

}
