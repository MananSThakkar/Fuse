package com.team8.fuse;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Landing extends AppCompatActivity {

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.landing);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser user = mAuth.getCurrentUser();
        if(user != null){
            finish();
            startActivity(new Intent(Landing.this, Chat.class));
        }
    }

    public void sign_in(View view){
        Intent intent = new Intent(this, SignIn.class);
        startActivity(intent);
    }

    public void sign_up(View view){
        Intent intent = new Intent(this, Get_Started.class);
        startActivity(intent);
    }
}
