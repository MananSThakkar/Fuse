package com.team8.fuse;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class passwordActivity extends AppCompatActivity {

    private EditText resetEmail;
    private Button resetPassword;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);

        resetEmail = (EditText)findViewById(R.id.etResetEmail);
        resetPassword = (Button)findViewById(R.id.btnResetPassword);
        mAuth = FirebaseAuth.getInstance();



        resetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userEmail = resetEmail.getText().toString().trim();

                if(userEmail.equals("")){
                    Toast.makeText(passwordActivity.this, "Please enter your registered Email address", Toast.LENGTH_SHORT).show();
                }else{
                    mAuth.sendPasswordResetEmail(userEmail).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                Toast.makeText(passwordActivity.this, "Please reset Email Sent", Toast.LENGTH_SHORT).show();
                                Logout();

                                startActivity(new Intent(passwordActivity.this, SignIn.class));
                            }else{
                                Toast.makeText(passwordActivity.this, "Error! Entered email address is not registered", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });
    }
    private final void Logout(){
        mAuth.signOut();
        finish();
        startActivity(new Intent(passwordActivity.this, SignIn.class));
    }
}
