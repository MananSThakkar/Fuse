package com.team8.fuse;

import android.media.Image;

public class Contacts {
    public String userName, userStatus, image;
}
