package com.team8.fuse;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SignIn extends AppCompatActivity {

    private EditText Email;
    private EditText Password;
    private TextView Info;
    private Button SignIn;
    private int counter = 3;
    private FirebaseAuth mAuth;
    private ProgressDialog progressDialog;
    private TextView forgotPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        Email = (EditText)findViewById(R.id.email);
        Password = (EditText)findViewById(R.id.password);
        Info = (TextView)findViewById(R.id.info);
        SignIn = (Button)findViewById(R.id.SignIn);
        forgotPassword = (TextView)findViewById(R.id.tvForgotPassword);

        Info.setText("Number of attempts remaining: 3");

        mAuth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);

        FirebaseUser user = mAuth.getCurrentUser();
        if(user != null){
            finish();
            startActivity(new Intent(com.team8.fuse.SignIn.this, MainPageContainerActivity.class));
        }

        SignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validate(Email.getText().toString(), Password.getText().toString());
            }
        });

        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(com.team8.fuse.SignIn.this, passwordActivity.class));
            }
        });
    }


    private void validate(String userEmail, String userPassword){
        progressDialog.setMessage("Loading Home Page");
        progressDialog.show();
        mAuth.signInWithEmailAndPassword(userEmail, userPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()) {
                    progressDialog.dismiss();
                    checkEmailVerification();
                }else{
                    Toast.makeText(com.team8.fuse.SignIn.this, "Login Failed", Toast.LENGTH_SHORT).show();
                    counter--;
                    Info.setText("Number of attempts remaining: " + counter);
                    progressDialog.dismiss();
                    if(counter == 0){
                        SignIn.setEnabled(false);
                    }

                }
            }
        });

    }

    private void checkEmailVerification(){
        FirebaseUser firebaseUser = mAuth.getInstance().getCurrentUser();
        Boolean emailflag = firebaseUser.isEmailVerified();

        if(emailflag){
            finish();
            startActivity(new Intent(com.team8.fuse.SignIn.this, MainPageContainerActivity.class));
            Toast.makeText(com.team8.fuse.SignIn.this, "Login Successful", Toast.LENGTH_SHORT).show();

        }else{
            Toast.makeText(this,"Verify your email", Toast.LENGTH_SHORT).show();
            mAuth.signOut();
        }
    }
}
