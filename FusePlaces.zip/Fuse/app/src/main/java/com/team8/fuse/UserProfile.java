package com.team8.fuse;

import android.os.Parcel;
import android.os.Parcelable;

public class UserProfile implements Parcelable {

    public String userName;
    public String userEmail;
    public String userStatus;

    public UserProfile(){

    }

    public UserProfile(String userName, String userEmail, String userStatus) {

        this.userName = userName;
        this.userEmail = userEmail;
        this.userStatus = userStatus;
    }

    protected UserProfile(Parcel in) {
        userName = in.readString();
        userEmail = in.readString();
        userStatus = in.readString();
    }

    public static final Creator<UserProfile> CREATOR = new Creator<UserProfile>() {
        @Override
        public UserProfile createFromParcel(Parcel in) {
            return new UserProfile(in);
        }

        @Override
        public UserProfile[] newArray(int size) {
            return new UserProfile[size];
        }
    };

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserStatus() {
        return userStatus;
    }

    public void setUserStatus(String userStatus) {
        this.userStatus = userStatus;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(userName);
        dest.writeString(userEmail);
        dest.writeString(userStatus);
    }
}
