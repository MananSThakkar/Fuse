package com.example.fuse;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class HomePage extends AppCompatActivity {

    FirebaseAuth mAuth;
    private Toolbar mToolbar;
  //  private Button logout;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        mAuth = FirebaseAuth.getInstance();

        mToolbar = (Toolbar)findViewById(R.id.main_app_bar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Fuse");

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_home:
                        Toast.makeText(HomePage.this, "Home", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.action_chats:
                        Toast.makeText(HomePage.this, "Chat", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(HomePage.this, Chat.class));
                        break;
                    case R.id.action_places:
                        Toast.makeText(HomePage.this, "Places", Toast.LENGTH_SHORT).show();
                        break;

                }
                return true;
            }
        });


    }

    private void Logout(){
        mAuth.signOut();
        finish();
        startActivity(new Intent(HomePage.this, Sign_In.class));
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        if(item.getItemId() == R.id.profileMenu){
            startActivity(new Intent(HomePage.this, Profile.class));
        }
        if(item.getItemId() == R.id.logoutMenu){
            Logout();
        }
        return super.onOptionsItemSelected(item);
    }


}